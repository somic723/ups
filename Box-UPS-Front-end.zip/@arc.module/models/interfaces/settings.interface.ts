export interface ISettings {
  appTitle: string;
  serverAddresses: string[];
  language: string;
  footerAlertCount: number;
}
