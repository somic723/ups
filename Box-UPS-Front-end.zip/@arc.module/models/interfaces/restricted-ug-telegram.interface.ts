export interface IRestrictedUgTelegram {
  restrictUgTelegramId: number;
  userGroupFk: number;
  telegramFk: number;
}