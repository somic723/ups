


export interface IUserGroup {
  title: string;
  userGroupId: number;
}
