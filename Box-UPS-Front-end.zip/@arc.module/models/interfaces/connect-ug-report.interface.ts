export interface IConnectUgReport {
  connectUserGroupReportId: number;
  userGroupFk: number;
  reportFk: number;
}