export interface IConnectUgSubmenu {
  connectUserGroupSubmenuId: number;
  userGroupFk: number;
  submenuFk: number;
}