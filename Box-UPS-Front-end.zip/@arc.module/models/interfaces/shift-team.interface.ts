import { IShift } from './shift.interface';
import { ITeam } from './team.interface';

export interface IShiftTeam {
  shift: IShift;
  team: ITeam;
}
