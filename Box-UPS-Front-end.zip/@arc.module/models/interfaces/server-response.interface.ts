export interface IServerResponse {
  telId: number
  message: string
}
