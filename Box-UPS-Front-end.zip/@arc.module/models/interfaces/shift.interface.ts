export interface IShift {
  shiftTimeId: number;
  title: string;
  isEditing: boolean;
  startTime: string;
  endTime: string;
}