export interface IModifyUser {
  username: string;
  name: string;
  family: string;
  password: string;
  oldPassword: string;
}
