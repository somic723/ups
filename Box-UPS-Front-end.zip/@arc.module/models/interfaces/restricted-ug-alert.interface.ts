export interface IRestrictedUgAlert {
  restrictUgAlertId: number;
  userGroupFk: number;
  alertFk: number;
}
