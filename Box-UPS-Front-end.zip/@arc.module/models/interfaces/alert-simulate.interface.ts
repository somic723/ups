export interface IAlertSimulate {
  alertId: number;
  prm1: string;
  prm2: string;
  prm3: string;
}
