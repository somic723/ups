export interface ITelegramSimulate {
  telId: number;
  data: string;
  srcId: number;
  dstId: number;
}