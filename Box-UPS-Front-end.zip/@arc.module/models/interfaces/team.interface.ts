export interface ITeam {
  shiftTeamId: number;
  title: string;
  color: string;
  isEditing: boolean;
  editTitle: string;
}