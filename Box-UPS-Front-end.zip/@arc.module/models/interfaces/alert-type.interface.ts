export interface IAlertType {
  name: string;
  value: number;
}
