export interface IShiftPair {
  ShiftTimeId: number;
  ShiftTeamId: number;
}