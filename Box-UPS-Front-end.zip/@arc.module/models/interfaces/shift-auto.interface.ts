import { IShiftSlot } from './shift-slot.interface';
export interface IShiftAuto {
  year: number;
  slots: IShiftSlot[];
}