export interface IShiftEdit {
  id: number;
  name: string;
  editName: string;
  editStartTime: string;
  editEndTime: string;
}