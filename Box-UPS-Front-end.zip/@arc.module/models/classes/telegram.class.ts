export class Telegram {

  constructor(telId: number, telData: any) {

    this.telId = telId;
    this.telData = telData;
  }
  telId: number;
  telData;
}
