import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'arc-sidenav-presenter',
  template: `<arc-sidenav-view

   ></arc-sidenav-view>`
})
export class ArcSidenavPresenter implements OnInit {


  constructor() { }

  async ngOnInit() {
  }


}
