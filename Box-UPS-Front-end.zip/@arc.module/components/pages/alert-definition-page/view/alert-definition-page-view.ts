import { Component, OnInit, Input, ViewChild } from '@angular/core';

@Component({
  selector: 'alert-definition-page-view',
  templateUrl: './alert-definition-page-view.html',
  styleUrls: ['./alert-definition-page-view.scss']
})
export class AlertDefinitionPageView implements OnInit {


  constructor() {
  }


  ngOnInit(): void {
  }

}
