import { Component, OnInit, AfterViewInit } from '@angular/core';


@Component({
    selector: 'alert-definition-page-presenter',
    template: `<alert-definition-page-view>
    </alert-definition-page-view>`
})

export class AlertDefinitionPagePresenter implements OnInit {


    ngOnInit() {

    }

}
