import { Component, OnInit, AfterViewInit } from '@angular/core';



@Component({
    selector: 'telegram-modification-page-presenter',
    template: `<telegram-modification-page-view>
    </telegram-modification-page-view>`
})

export class TelegramModificationPagePresenter implements OnInit {


    ngOnInit() {

    }

}
