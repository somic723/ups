import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'telegram-modification-page-view',
  templateUrl: './telegram-modification-page-view.html',
  styleUrls: ['./telegram-modification-page-view.scss']
})
export class TelegramModificationPageView implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
