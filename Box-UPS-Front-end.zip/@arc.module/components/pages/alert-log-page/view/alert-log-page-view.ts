import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'alert-log-page-view',
  templateUrl: './alert-log-page-view.html',
  styleUrls: ['./alert-log-page-view.scss']
})
export class AlertLogPageView implements OnInit {
  ngOnInit() { }
}

