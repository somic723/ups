import { Component, OnInit, Input } from '@angular/core';

import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'menu-page-presenter',
  template: `<menu-page-view

   ></menu-page-view>`
})
export class MenuPagePresenter implements OnInit {


  constructor() { }

  async ngOnInit() {
  }









}
