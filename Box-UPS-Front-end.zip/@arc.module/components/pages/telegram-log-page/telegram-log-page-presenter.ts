import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'telegram-log-page-presenter',
  template: `<telegram-log-page-view></telegram-log-page-view>`
})
export class TelegramLogPagePresenter implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
