import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'telegram-log-page-view',
  templateUrl: './telegram-log-page-view.html',
  styleUrls: ['./telegram-log-page-view.scss']
})
export class TelegramLogPageView implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
