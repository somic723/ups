import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainups',
  templateUrl: './mainups.component.html',
  styleUrls: ['./mainups.component.scss']
})
export class MainupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
